# Dashboard
Dashboard for load profile analysis

Must include data and results folder in the same folder as the .py file to run code successfully.

Modules installed:
dash
dash-bootstrap-components
pandas
scipy
datetime
openpyxl
